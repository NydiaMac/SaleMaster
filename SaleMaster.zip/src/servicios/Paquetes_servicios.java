/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.PaqueteriaDatos;

/**
 *
 * @author juan
 */
public class Paquetes_servicios {
   private final String tabla = "Paquetes";
   /**
    * Metodo que guarda un registro de un paquete en la base de datos.
    * @param conexion El parametro conexion es objeto con la informacion de la conexion con la base de datos.
    * @param paquete EL parametro paquete contiene la informacion que sera guardada en la base de datos.
    * @throws SQLException 
    */
   public void guardar(Connection conexion, PaqueteriaDatos paquete) throws SQLException{
      try{
         PreparedStatement consulta;
         if(paquete.getCodigo()== null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setString(1, paquete.getRemitente());
            consulta.setString(2, paquete.getDestinatario());
            consulta.setString(3, paquete.getDescripcion());
            consulta.setInt(4, paquete.getNpaquetes());
            consulta.setFloat(5, paquete.getPeso());
            consulta.setFloat(6, paquete.getImporte());
            consulta.setString(7, paquete.getOrigen());
            consulta.setString(8, paquete.getDestino());
            consulta.setString(9, paquete.getFecha());
            consulta.setString(10,paquete.getUnidad());
            consulta.setString(11, paquete.getChofer());
            consulta.setString(12,paquete.getEntregado());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Remitente = ?, Destinatario = ?, Descripcion = ?, NPaquetes = ?, Peso = ?, Importe = ?, Origen = ?, Destino = ?, Fecha = ?,Unidad = ?,Chofer = ?,Entregado = ? WHERE Codigo = ?");
            consulta.setString(1, paquete.getRemitente());
            consulta.setString(2, paquete.getDestinatario());
            consulta.setString(3, paquete.getDescripcion());
            consulta.setInt(4, paquete.getNpaquetes());
            consulta.setFloat(5, paquete.getPeso());
            consulta.setFloat(6, paquete.getImporte());
            consulta.setString(7, paquete.getOrigen());
            consulta.setString(8, paquete.getDestino());
            consulta.setString(9, paquete.getFecha());
            consulta.setString(10,paquete.getUnidad());
            consulta.setString(11, paquete.getChofer());
            consulta.setString(12,paquete.getEntregado());
            consulta.setInt(13, paquete.getCodigo());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera un registro de la base de datos a partir de un ID
    * @param conexion El parametro conexion contiene la informacion de la coneccion con la base de datos.
    * @param codigo El parametro codigo contiene el numero de registro que se desea recuperar
    * @return devuelve un objeto de la clase PaqueteriaDatos con la informacion del paquete recuperado.
    * @throws SQLException 
    */
   public PaqueteriaDatos recuperarPorId(Connection conexion, int codigo) throws SQLException {
      PaqueteriaDatos paquete = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado  FROM " + this.tabla + " WHERE Codigo = ?" );
         consulta.setInt(1, codigo);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            paquete = new PaqueteriaDatos(resultado.getString("Remitente"), resultado.getString("Destinatario"), resultado.getString("Descripcion"), resultado.getInt("NPaquetes"), resultado.getFloat("Peso"),codigo,resultado.getFloat("Importe"),resultado.getString("Origen"),resultado.getString("Destino"), resultado.getString("Fecha"),resultado.getString("Unidad"),resultado.getString("Chofer"),resultado.getString("Entregado"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return paquete;
   }
   /**
    * Metodo que elimina un registro de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @param paquete El parametro paquete contiene la informaciond del paquete que se desea eliminar.
    * @throws SQLException 
    */
   public void eliminar(Connection conexion, PaqueteriaDatos paquete) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID = ?");
         consulta.setInt(1, paquete.getCodigo());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera todos los registros de paquetes de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @return devuelve una lista de objetos de la clase PaqueteriaDatos con todos los registros de paquetes.
    * @throws SQLException 
    */
   public List<PaqueteriaDatos> recuperarTodas(Connection conexion) throws SQLException{
      List<PaqueteriaDatos> paquetes = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Codigo,Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado FROM " + this.tabla + " ORDER BY Fecha");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            paquetes.add(new PaqueteriaDatos(resultado.getString("Remitente"), resultado.getString("Destinatario"), resultado.getString("Descripcion"), resultado.getInt("NPaquetes"), resultado.getFloat("Peso"),resultado.getInt("Codigo"),resultado.getFloat("Importe"),resultado.getString("Origen"),resultado.getString("Destino"), resultado.getString("Fecha"),resultado.getString("Unidad"),resultado.getString("Chofer"),resultado.getString("Entregado")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return paquetes;
   }
}