/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.PaqueteriaDatos;

/**
 *
 * @author juan
 */
public class Paquetes_servicios {
   private final String tabla = "Paquetes";
   public void guardar(Connection conexion, PaqueteriaDatos paquete) throws SQLException{
      try{
         PreparedStatement consulta;
         if(paquete.getCodigo()== null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setString(1, paquete.getRemitente());
            consulta.setString(2, paquete.getDestinatario());
            consulta.setString(3, paquete.getDescripcion());
            consulta.setInt(4, paquete.getNpaquetes());
            consulta.setFloat(5, paquete.getPeso());
            consulta.setFloat(6, paquete.getImporte());
            consulta.setString(7, paquete.getOrigen());
            consulta.setString(8, paquete.getDestino());
            consulta.setString(9, paquete.getFecha());
            consulta.setString(10,paquete.getUnidad());
            consulta.setString(11, paquete.getChofer());
            consulta.setString(12,paquete.getEntregado());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Remitente = ?, Destinatario = ?, Descripcion = ?, NPaquetes = ?, Peso = ?, Importe = ?, Origen = ?, Destino = ?, Fecha = ?,Unidad = ?,Chofer = ?,Entregado = ? WHERE Codigo = ?");
            consulta.setString(1, paquete.getRemitente());
            consulta.setString(2, paquete.getDestinatario());
            consulta.setString(3, paquete.getDescripcion());
            consulta.setInt(4, paquete.getNpaquetes());
            consulta.setFloat(5, paquete.getPeso());
            consulta.setFloat(6, paquete.getImporte());
            consulta.setString(7, paquete.getOrigen());
            consulta.setString(8, paquete.getDestino());
            consulta.setString(9, paquete.getFecha());
            consulta.setString(10,paquete.getUnidad());
            consulta.setString(11, paquete.getChofer());
            consulta.setString(12,paquete.getEntregado());
            consulta.setInt(13, paquete.getCodigo());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public PaqueteriaDatos recuperarPorId(Connection conexion, int codigo) throws SQLException {
      PaqueteriaDatos paquete = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado  FROM " + this.tabla + " WHERE Codigo = ?" );
         consulta.setInt(1, codigo);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            paquete = new PaqueteriaDatos(resultado.getString("Remitente"), resultado.getString("Destinatario"), resultado.getString("Descripcion"), resultado.getInt("NPaquetes"), resultado.getFloat("Peso"),codigo,resultado.getFloat("Importe"),resultado.getString("Origen"),resultado.getString("Destino"), resultado.getString("Fecha"),resultado.getString("Unidad"),resultado.getString("Chofer"),resultado.getString("Entregado"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return paquete;
   }
   public void eliminar(Connection conexion, PaqueteriaDatos paquete) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID = ?");
         consulta.setInt(1, paquete.getCodigo());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public List<PaqueteriaDatos> recuperarTodas(Connection conexion) throws SQLException{
      List<PaqueteriaDatos> paquetes = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Codigo,Remitente,Destinatario,Descripcion,NPaquetes,Peso,Importe,Origen,Destino,Fecha,Unidad,Chofer,Entregado FROM " + this.tabla + " ORDER BY Fecha");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            paquetes.add(new PaqueteriaDatos(resultado.getString("Remitente"), resultado.getString("Destinatario"), resultado.getString("Descripcion"), resultado.getInt("NPaquetes"), resultado.getFloat("Peso"),resultado.getInt("Codigo"),resultado.getFloat("Importe"),resultado.getString("Origen"),resultado.getString("Destino"), resultado.getString("Fecha"),resultado.getString("Unidad"),resultado.getString("Chofer"),resultado.getString("Entregado")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return paquetes;
   }
}