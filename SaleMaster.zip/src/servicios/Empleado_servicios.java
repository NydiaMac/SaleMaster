/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

/**
 *
 * @author juan
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Empleado;
public class Empleado_servicios {
   private final String tabla = "Empleado";
   public void guardar(Connection conexion, Empleado empleado) throws SQLException{
      try{
         PreparedStatement consulta;
         if(empleado.getId_empleado() == null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Nombre,Tipo,Domicilio,Localidad,Telefono,CP,Sexo,Estado_Civil,Nacionalidad,Fecha_nacimiento) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setString(1, empleado.getNombre());
            consulta.setString(2, empleado.getTipo());
            consulta.setString(3, empleado.getDomicilio());
            consulta.setString(4, empleado.getLocalidad());
            consulta.setInt(5, empleado.getTelefono());
            consulta.setInt(6, empleado.getCP());
            consulta.setString(7, empleado.getSexo());
            consulta.setString(8, empleado.getEstado_civil());
            consulta.setString(9, empleado.getNacionalidad());
            consulta.setString(10,empleado.getFecha_nacimiento());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Nombre = ?, Tipo = ?, Domicilio = ?, Localidad = ?, Telefono = ?, CP = ?, Sexo = ?, Estado_Civil = ?, Nacionalidad = ?,Fecha_nacimiento = ? WHERE ID = ?");
            consulta.setString(1, empleado.getNombre());
            consulta.setString(2, empleado.getTipo());
            consulta.setString(3, empleado.getDomicilio());
            consulta.setString(4, empleado.getLocalidad());
            consulta.setInt(5, empleado.getTelefono());
            consulta.setInt(6, empleado.getCP());
            consulta.setString(7, empleado.getSexo());
            consulta.setString(8, empleado.getEstado_civil());
            consulta.setString(9, empleado.getNacionalidad());
            consulta.setString(10,empleado.getFecha_nacimiento());
            consulta.setInt(11, empleado.getId_empleado());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public Empleado recuperarPorId(Connection conexion, int id_empleado) throws SQLException {
      Empleado empleado = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Nombre, Tipo, Domicilio, Localidad, Telefono, CP, Sexo, Estado_Civil, Nacionalidad, Fecha_nacimiento  FROM " + this.tabla + " WHERE ID = ?" );
         consulta.setInt(1, id_empleado);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            empleado = new Empleado(id_empleado, resultado.getString("Nombre"), resultado.getString("Tipo"), resultado.getString("Domicilio"), resultado.getString("Localidad"), resultado.getInt("Telefono"),resultado.getInt("CP"),resultado.getString("Sexo"),resultado.getString("Estado_Civil"), resultado.getString("Nacionalidad"),resultado.getString("Fecha_nacimiento"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return empleado;
   }
   public void eliminar(Connection conexion, Empleado empleado) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID = ?");
         consulta.setInt(1, empleado.getId_empleado());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public List<Empleado> recuperarTodas(Connection conexion) throws SQLException{
      List<Empleado> empleados = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT ID, Nombre, Tipo, Domicilio, Localidad, Telefono, CP, Sexo, Estado_Civil, Nacionalidad,Fecha_nacimiento FROM " + this.tabla + " ORDER BY sexo");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            empleados.add(new Empleado(resultado.getInt("ID"), resultado.getString("Nombre"), resultado.getString("Tipo"), resultado.getString("Domicilio"), resultado.getString("Localidad"), resultado.getInt("Telefono"),resultado.getInt("CP"),resultado.getString("Sexo"),resultado.getString("Estado_Civil"), resultado.getString("Nacionalidad"),resultado.getString("Fecha_nacimiento")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return empleados;
   }
}