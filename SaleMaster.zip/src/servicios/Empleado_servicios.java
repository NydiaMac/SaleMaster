/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Empleado;

/**
 *
 * @author juan
 */
public class Empleado_servicios {
   private final String tabla = "Empleado";
   /**
    * Constructor de la clase.
    */
   public Empleado_servicios(){
       
   }
   /**
    * Metodo que guarda un registro de un empleado vendido en la base de datos.
    * @param conexion El parametro conexion es objeto con la informacion de la conexion con la base de datos.
    * @param empleado EL parametro empleado contiene la informacion que sera guardada en la base de datos.
    * @throws SQLException 
    */
   public void guardar(Connection conexion, Empleado empleado) throws SQLException{
      try{
         PreparedStatement consulta;
         if(empleado.getId_empleado() == null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Nombre,Tipo,Domicilio,Localidad,Telefono,CP,Sexo,Estado_Civil,Nacionalidad,Fecha_nacimiento) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setString(1, empleado.getNombre());
            consulta.setString(2, empleado.getTipo());
            consulta.setString(3, empleado.getDomicilio());
            consulta.setString(4, empleado.getLocalidad());
            consulta.setString(5, empleado.getTelefono());
            consulta.setString(6, empleado.getCP());
            consulta.setString(7, empleado.getSexo());
            consulta.setString(8, empleado.getEstado_civil());
            consulta.setString(9, empleado.getNacionalidad());
            consulta.setString(10,empleado.getFecha_nacimiento());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Nombre = ?, Tipo = ?, Domicilio = ?, Localidad = ?, Telefono = ?, CP = ?, Sexo = ?, Estado_Civil = ?, Nacionalidad = ?,Fecha_nacimiento = ? WHERE ID = ?");
            consulta.setString(1, empleado.getNombre());
            consulta.setString(2, empleado.getTipo());
            consulta.setString(3, empleado.getDomicilio());
            consulta.setString(4, empleado.getLocalidad());
            consulta.setString(5, empleado.getTelefono());
            consulta.setString(6, empleado.getCP());
            consulta.setString(7, empleado.getSexo());
            consulta.setString(8, empleado.getEstado_civil());
            consulta.setString(9, empleado.getNacionalidad());
            consulta.setString(10,empleado.getFecha_nacimiento());
            consulta.setInt(11, empleado.getId_empleado());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera un registro de la base de datos a partir de un ID
    * @param conexion El parametro conexion contiene la informacion de la coneccion con la base de datos.
    * @param id_empleado El parametro id_empleado contiene el numero de registro que se desea recuperar
    * @return devuelve un objeto de la clase Empleado con la informacion del empleado recuperado.
    * @throws SQLException 
    */
   public Empleado recuperarPorId(Connection conexion, int id_empleado) throws SQLException {
      Empleado empleado = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Nombre, Tipo, Domicilio, Localidad, Telefono, CP, Sexo, Estado_Civil, Nacionalidad, Fecha_nacimiento  FROM " + this.tabla + " WHERE ID = ?" );
         consulta.setInt(1, id_empleado);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            empleado = new Empleado(id_empleado, resultado.getString("Nombre"), resultado.getString("Tipo"), resultado.getString("Domicilio"), resultado.getString("Localidad"), resultado.getString("Telefono"),resultado.getString("CP"),resultado.getString("Sexo"),resultado.getString("Estado_Civil"), resultado.getString("Nacionalidad"),resultado.getString("Fecha_nacimiento"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return empleado;
   }
   /**
    * Metodo que elimina un registro de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @param empleado El parametro empleado contiene la informaciond del empleado que se desea eliminar.
    * @throws SQLException 
    */
   public void eliminar(Connection conexion, Empleado empleado) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID = ?");
         consulta.setInt(1, empleado.getId_empleado());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera todos los registros de empleados de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @return devuelve una lista de objetos de la clase Empleado con todos los registros de Empleados registrados.
    * @throws SQLException 
    */
   public List<Empleado> recuperarTodas(Connection conexion) throws SQLException{
      List<Empleado> empleados = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT ID, Nombre, Tipo, Domicilio, Localidad, Telefono, CP, Sexo, Estado_Civil, Nacionalidad,Fecha_nacimiento FROM " + this.tabla + " ORDER BY sexo");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            empleados.add(new Empleado(resultado.getInt("ID"), resultado.getString("Nombre"), resultado.getString("Tipo"), resultado.getString("Domicilio"), resultado.getString("Localidad"), resultado.getString("Telefono"),resultado.getString("CP"),resultado.getString("Sexo"),resultado.getString("Estado_Civil"), resultado.getString("Nacionalidad"),resultado.getString("Fecha_nacimiento")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return empleados;
   }
}