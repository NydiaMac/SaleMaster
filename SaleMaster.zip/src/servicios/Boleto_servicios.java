/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Boleto;

/**
 *
 * @author juan
 */

public class Boleto_servicios {
   private final String tabla = "Boletos";
   public void guardar(Connection conexion, Boleto boleto) throws SQLException{
      try{
         PreparedStatement consulta;
         if(boleto.getID_boleto()== null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Asiento,Destino,Fecha,Hora,ID_suburban) VALUES(?, ?, ?, ?, ?)");
            consulta.setInt(1, boleto.getNo_Asiento());
            consulta.setString(2, boleto.getDestino());
            consulta.setString(3, boleto.getFecha());
            consulta.setString(4, boleto.getHora());
            consulta.setInt(5, boleto.getID_suburban());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Asiento = ?, Destino = ?, Fecha = ?, Hora = ?, ID_suburban = ? WHERE ID_boleto = ?");
            consulta.setInt(1, boleto.getNo_Asiento());
            consulta.setString(2, boleto.getDestino());
            consulta.setString(3, boleto.getFecha());
            consulta.setString(4, boleto.getHora());
            consulta.setInt(5, boleto.getID_suburban());
            consulta.setInt(6, boleto.getID_boleto());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public Boleto recuperarPorId(Connection conexion, int id_boleto) throws SQLException {
      Boleto boleto = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Asiento,Destino,Fecha,Hora,ID_suburban FROM " + this.tabla + " WHERE ID_boleto = ?" );
         consulta.setInt(1, id_boleto);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            boleto = new Boleto(id_boleto, resultado.getInt("Asiento"), resultado.getString("Destino"), resultado.getString("Fecha"), resultado.getString("Hora"), resultado.getInt("ID_suburban"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return boleto;
   }
   public void eliminar(Connection conexion, Boleto boleto) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID_boleto = ?");
         consulta.setInt(1, boleto.getID_boleto());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   public List<Boleto> recuperarTodas(Connection conexion) throws SQLException{
      List<Boleto> boletos = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT ID_boleto, Asiento, Destino, Fecha, Hora, ID_suburban FROM " + this.tabla + " ORDER BY Asiento");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            boletos.add(new Boleto(resultado.getInt("ID_boleto"), resultado.getInt("Asiento"), resultado.getString("Destino"), resultado.getString("Fecha"), resultado.getString("Hora"), resultado.getInt("ID_suburban")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return boletos;
   }
}