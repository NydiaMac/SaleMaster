/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Boleto;

/**
 *
 * @author juan
 */

public class Boleto_servicios {
   private final String tabla = "Boletos";
   /**
    * Metodo que guarda un registro de un boleto vendido en la base de datos.
    * @param conexion El parametro conexion es objeto con la informacion de la conexion con la base de datos.
    * @param boleto EL parametro boleto contiene la informacion que sera guardada en la base de datos.
    * @throws SQLException 
    */
   public void guardar(Connection conexion, Boleto boleto) throws SQLException{
      try{
         PreparedStatement consulta;
         if(boleto.getID_boleto()== null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Asiento,Destino,Fecha,Hora,ID_suburban,Pasajero) VALUES(?, ?, ?, ?, ?, ?)");
            consulta.setInt(1, boleto.getNo_Asiento());
            consulta.setString(2, boleto.getDestino());
            consulta.setString(3, boleto.getFecha());
            consulta.setString(4, boleto.getHora());
            consulta.setInt(5, boleto.getID_suburban());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Asiento = ?, Destino = ?, Fecha = ?, Hora = ?, ID_suburban = ?,Pasajero = ? WHERE ID_boleto = ?");
            consulta.setInt(1, boleto.getNo_Asiento());
            consulta.setString(2, boleto.getDestino());
            consulta.setString(3, boleto.getFecha());
            consulta.setString(4, boleto.getHora());
            consulta.setInt(5, boleto.getID_suburban());
            consulta.setInt(6, boleto.getID_boleto());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera un registro de la base de datos a partir de un ID
    * @param conexion El parametro conexion contiene la informacion de la coneccion con la base de datos.
    * @param id_boleto El parametro id_boleto contiene el numero de registro que se desea recuperar
    * @return devuelve un objeto de la clase Boleto con la informacion del boleto recuperado.
    * @throws SQLException 
    */
   public Boleto recuperarPorId(Connection conexion, int id_boleto) throws SQLException {
      Boleto boleto = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Asiento,Destino,Fecha,Hora,ID_suburban FROM " + this.tabla + " WHERE ID_boleto = ?" );
         consulta.setInt(1, id_boleto);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            boleto = new Boleto(id_boleto, resultado.getInt("Asiento"), resultado.getString("Destino"), resultado.getString("Fecha"), resultado.getString("Hora"), resultado.getInt("ID_suburban"),resultado.getString("Pasajero"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return boleto;
   }
   /**
    * Metodo que elimina un registro de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @param boleto El parametro boleto contiene la informaciond del boleto que se desea eliminar.
    * @throws SQLException 
    */
   public void eliminar(Connection conexion, Boleto boleto) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID_boleto = ?");
         consulta.setInt(1, boleto.getID_boleto());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera todos los registros de boletos de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @return devuelve una lista de objetos de la clase Boleto con todos los registros de boletos vendidos.
    * @throws SQLException 
    */
   public List<Boleto> recuperarTodas(Connection conexion) throws SQLException{
      List<Boleto> boletos = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT ID_boleto, Asiento, Destino, Fecha, Hora, ID_suburban, Pasajero FROM " + this.tabla + " ORDER BY Asiento");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            boletos.add(new Boleto(resultado.getInt("ID_boleto"), resultado.getInt("Asiento"), resultado.getString("Destino"), resultado.getString("Fecha"), resultado.getString("Hora"), resultado.getInt("ID_suburban"),resultado.getString("Pasajero")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return boletos;
   }
}