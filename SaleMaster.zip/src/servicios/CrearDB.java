/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author juan
 */
public class CrearDB {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        Connection c = null;
        Statement stm = null;
        
        try{
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:SaleMaster");
            stm = c.createStatement();
            String sql =  "CREATE TABLE Empleado"+"(ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"+"Nombre VARCHAR(50) NOT NULL,"+"Tipo VARCHAR(15) NOT NULL,"+"Domicilio VARCHAR(80) NOT NULL,"+"Localidad VARCHAR(80) NOT NULL,"+"Telefono INTEGER(15) NOT NULL,"+"CP INTEGER(8) NOT NULL,"+"Sexo VARCHAR(10) NOT NULL,"+"Estado_Civil VARCHAR(12) NOT NULL,"+"Nacionalidad VARCHAR(30) NOT NULL,"+"Fecha_nacimiento VARCHAR(15) NOT NULL);";
            stm.execute(sql);
            String sql2 =  "CREATE TABLE Paquetes"+"(Codigo INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"+"Remitente VARCHAR(50) NOT NULL,"+"Destinatario VARCHAR(50)NOT NULL,"+"Descripcion VARCHAR(180),"+"NPaquetes INTEGER NOT NULL,"+"Peso FLOAT NOT NULL,"+"Importe FLOAT NOT NULL,"+"Origen VARCHAR(50) NOT NULL,"+"Destino VARCHAR(50) NOT NULL,"+"Fecha VARCHAR(12) NOT NULL,"+"Unidad VARCHAR(10) NOT NULL,"+"Chofer VARCHAR(50) NOT NULL,"+"Entregado VARCHAR(10) NOT NULL)";
            stm.execute(sql2);
            
            System.out.println("La base de datos se abrio exitosamente.");
            stm.close();
            c.close();
        }catch(SQLException e){
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }   
    }    
}
