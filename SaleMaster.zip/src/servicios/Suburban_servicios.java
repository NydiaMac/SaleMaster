/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelos.Suburban;

/**
 *
 * @author juan
 */
public class Suburban_servicios {
       private final String tabla = "Suburban";
    /**
    * Metodo que guarda un registro de una suburban en la base de datos.
    * @param conexion El parametro conexion es objeto con la informacion de la conexion con la base de datos.
    * @param suburban EL parametro suburban contiene la informacion que sera guardada en la base de datos.
    * @throws SQLException 
    */
   public void guardar(Connection conexion, Suburban suburban) throws SQLException{
      try{
         PreparedStatement consulta;
         if(suburban.getID_suburban()== null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(Asiento1,Asiento2,Asiento3,Asiento4,Asiento5,Asiento6,Asiento7,Asiento8,Asiento9,Asiento10,Asiento11,Asiento12,Asiento13,Asiento14,Asiento15,Asiento16,Asiento17) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setBoolean(1, suburban.getAsiento1());
            consulta.setBoolean(2, suburban.getAsiento2());
            consulta.setBoolean(3, suburban.getAsiento3());
            consulta.setBoolean(4, suburban.getAsiento4());
            consulta.setBoolean(5, suburban.getAsiento5());
            consulta.setBoolean(6, suburban.getAsiento6());
            consulta.setBoolean(7, suburban.getAsiento7());
            consulta.setBoolean(8, suburban.getAsiento8());
            consulta.setBoolean(9, suburban.getAsiento9());
            consulta.setBoolean(10, suburban.getAsiento10());
            consulta.setBoolean(11, suburban.getAsiento11());
            consulta.setBoolean(12, suburban.getAsiento12());
            consulta.setBoolean(13, suburban.getAsiento13());
            consulta.setBoolean(14, suburban.getAsiento14());
            consulta.setBoolean(15, suburban.getAsiento15());
            consulta.setBoolean(16, suburban.getAsiento16());
            consulta.setBoolean(17, suburban.getAsiento17());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET Asiento1 = ?,Asiento2 = ?,Asiento3 = ?,Asiento4 = ?,Asiento5 = ?,Asiento6 = ?,Asiento7 = ?,Asiento8 = ?,Asiento9 = ?,Asiento10 = ?,Asiento11 = ?,Asiento12 = ?,Asiento13 = ?,Asiento14 = ?,Asiento15 = ?,Asiento16 = ?,Asiento17 = ? WHERE ID_suburban = ?");
            consulta.setBoolean(1, suburban.getAsiento1());
            consulta.setBoolean(2, suburban.getAsiento2());
            consulta.setBoolean(3, suburban.getAsiento3());
            consulta.setBoolean(4, suburban.getAsiento4());
            consulta.setBoolean(5, suburban.getAsiento5());
            consulta.setBoolean(6, suburban.getAsiento6());
            consulta.setBoolean(7, suburban.getAsiento7());
            consulta.setBoolean(8, suburban.getAsiento8());
            consulta.setBoolean(9, suburban.getAsiento9());
            consulta.setBoolean(10, suburban.getAsiento10());
            consulta.setBoolean(11, suburban.getAsiento11());
            consulta.setBoolean(12, suburban.getAsiento12());
            consulta.setBoolean(13, suburban.getAsiento13());
            consulta.setBoolean(14, suburban.getAsiento14());
            consulta.setBoolean(15, suburban.getAsiento15());
            consulta.setBoolean(16, suburban.getAsiento16());
            consulta.setBoolean(17, suburban.getAsiento17());
            consulta.setInt(18, suburban.getID_suburban());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera un registro de la base de datos a partir de un ID
    * @param conexion El parametro conexion contiene la informacion de la coneccion con la base de datos.
    * @param id_suburban El parametro id_suburban contiene el numero de registro que se desea recuperar
    * @return devuelve un objeto de la clase Suburban con la informacion de la suburban recuperada.
    * @throws SQLException 
    */
   public Suburban recuperarPorId(Connection conexion, int id_suburban) throws SQLException {
      Suburban suburban = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Asiento1,Asiento2,Asiento3,Asiento4,Asiento5,Asiento6,Asiento7,Asiento8,Asiento9,Asiento10,Asiento11,Asiento12,Asiento13,Asiento14,Asiento15,Asiento16,Asiento17 FROM " + this.tabla + " WHERE ID_suburban = ?" );
         consulta.setInt(1, id_suburban);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            suburban = new Suburban(id_suburban, resultado.getBoolean("Asiento1"),resultado.getBoolean("Asiento2"),resultado.getBoolean("Asiento3"),resultado.getBoolean("Asiento4"),resultado.getBoolean("Asiento5"),resultado.getBoolean("Asiento6"),resultado.getBoolean("Asiento7"),resultado.getBoolean("Asiento8"),resultado.getBoolean("Asiento9"),resultado.getBoolean("Asiento10"),resultado.getBoolean("Asiento11"),resultado.getBoolean("Asiento12"),resultado.getBoolean("Asiento13"),resultado.getBoolean("Asiento14"),resultado.getBoolean("Asiento15"),resultado.getBoolean("Asiento16"),resultado.getBoolean("Asiento17"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return suburban;
   }
   /**
    * Metodo que elimina un registro de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @param suburban El parametro suburban contiene la informaciond de la suburban que se desea eliminar.
    * @throws SQLException 
    */
   public void eliminar(Connection conexion, Suburban suburban) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " + this.tabla + " WHERE ID_suburban = ?");
         consulta.setInt(1, suburban.getID_suburban());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   /**
    * Metodo que recupera todos los registros de suburban de la base de datos.
    * @param conexion El parametro conexion contiene la informacion de la conexion con la base de datos.
    * @return devuelve una lista de objetos de la clase Suburban con todos los registros de Suburban registrados.
    * @throws SQLException 
    */
   public List<Suburban> recuperarTodas(Connection conexion) throws SQLException{
      List<Suburban> suburban_list = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT Asiento1,Asiento2,Asiento3,Asiento4,Asiento5,Asiento6,Asiento7,Asiento8,Asiento9,Asiento10,Asiento11,Asiento12,Asiento13,Asiento14,Asiento15,Asiento16,Asiento17 FROM " + this.tabla + " ORDER BY ID_suburban");
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            suburban_list.add(new Suburban(resultado.getInt("ID_suburban"),resultado.getBoolean("Asiento1"),resultado.getBoolean("Asiento2"),resultado.getBoolean("Asiento3"),resultado.getBoolean("Asiento4"),resultado.getBoolean("Asiento5"),resultado.getBoolean("Asiento6"),resultado.getBoolean("Asiento7"),resultado.getBoolean("Asiento8"),resultado.getBoolean("Asiento9"),resultado.getBoolean("Asiento10"),resultado.getBoolean("Asiento11"),resultado.getBoolean("Asiento12"),resultado.getBoolean("Asiento13"),resultado.getBoolean("Asiento14"),resultado.getBoolean("Asiento15"),resultado.getBoolean("Asiento16"),resultado.getBoolean("Asiento17")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return suburban_list;
   }
}
