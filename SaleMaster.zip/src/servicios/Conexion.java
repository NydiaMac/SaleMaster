/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

/**
 *
 * @author juan
 */
import java.sql.*;

public class Conexion {
   private static Connection cnx = null;
   public static Connection obtener() throws SQLException, ClassNotFoundException {
      if (cnx == null) {
         try {
            Class.forName("org.sqlite.JDBC");
            String uri= System.getProperty("user.dir");
            //cnx = DriverManager.getConnection("jdbc:sqlite://home/juan/NetBeansProjects/SaleMaster/SQLite/SaleMaster");
            //cnx = DriverManager.getConnection("jdbc:sqlite:"+uri);
            cnx = DriverManager.getConnection("jdbc:sqlite:SaleMaster");
         } 
         catch (SQLException ex) {
            throw new SQLException(ex);
         } catch (ClassNotFoundException ex) {
            throw new ClassCastException(ex.getMessage());
         }
      }
      return cnx;
   }
   public static void cerrar() throws SQLException {
      if (cnx != null) {
         cnx.close();
      }
   }
}