/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;
import java.sql.*;

/**
 *
 * @author juan
 */
public class Conexion {
   private static Connection cnx = null;
   /**
    * Contructor de la clase.
    */
   public Conexion(){
   }
   /**
    * Metodo que obtiene la conexion con la base de datos
    * @return devuelve null si no puede conectar con la base de datos y la direccion de la base de datos en caso contrario.
    * @throws SQLException
    * @throws ClassNotFoundException 
    */
   public static Connection obtener() throws SQLException, ClassNotFoundException {
      if (cnx == null) {
         try {
            Class.forName("org.sqlite.JDBC");
            String uri= System.getProperty("user.dir");
            //cnx = DriverManager.getConnection("jdbc:sqlite://home/juan/NetBeansProjects/SaleMaster/SQLite/SaleMaster");
            //cnx = DriverManager.getConnection("jdbc:sqlite:"+uri);
            cnx = DriverManager.getConnection("jdbc:sqlite:SaleMaster");
         } 
         catch (SQLException ex) {
            throw new SQLException(ex);
         } catch (ClassNotFoundException ex) {
            throw new ClassCastException(ex.getMessage());
         }
      }
      return cnx;
   }
   /**
    * Metodo que cierra la conexion con la base de datos
    * @throws SQLException 
    */
   public static void cerrar() throws SQLException {
      if (cnx != null) {
         cnx.close();
      }
   }
}