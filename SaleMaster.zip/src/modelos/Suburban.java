/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Suburban {
    private final Integer ID_suburban;
    private Boolean Asiento1;
    private Boolean Asiento2;
    private Boolean Asiento3;
    private Boolean Asiento4;
    private Boolean Asiento5;
    private Boolean Asiento6;
    private Boolean Asiento7;
    private Boolean Asiento8;
    private Boolean Asiento9;
    private Boolean Asiento10;
    private Boolean Asiento11;
    private Boolean Asiento12;
    private Boolean Asiento13;
    private Boolean Asiento14;
    private Boolean Asiento15;
    private Boolean Asiento16;
    private Boolean Asiento17;
    
    public Suburban(){
        ID_suburban = null;
        Asiento1 = false;
        Asiento2 = false;
        Asiento3 = false;
        Asiento4 = false;
        Asiento5 = false;
        Asiento6 = false;
        Asiento7 = false;
        Asiento8 = false;
        Asiento9 = false;
        Asiento10 = false;
        Asiento11 = false;
        Asiento12 = false;
        Asiento13 = false;
        Asiento14 = false;
        Asiento15 = false;
        Asiento16 = false;
        Asiento17 = false;
    }
    public Suburban(Integer id,Boolean a1,Boolean a2,
                        Boolean a3,Boolean a4,Boolean a5,
                        Boolean a6,Boolean a7,Boolean a8,
                        Boolean a9,Boolean a10,Boolean a11,
                        Boolean a12,Boolean a13,Boolean a14,
                        Boolean a15,Boolean a16,Boolean a17){
        ID_suburban = id;
        Asiento1 = a1;
        Asiento2 = a2;
        Asiento3 = a3;
        Asiento4 = a4;
        Asiento5 = a5;
        Asiento6 = a6;
        Asiento7 = a7;
        Asiento8 = a8;
        Asiento9 = a9;
        Asiento10 = a10;
        Asiento11 = a11;
        Asiento12 = a12;
        Asiento13 = a13;
        Asiento14 = a14;
        Asiento15 = a15;
        Asiento16 = a16;
        Asiento17 = a17;
    }
    public Integer getID_suburban(){return ID_suburban;}
    public Boolean getAsiento1(){return Asiento1;}
    public Boolean getAsiento2(){return Asiento2;}
    public Boolean getAsiento3(){return Asiento3;}
    public Boolean getAsiento4(){return Asiento4;}
    public Boolean getAsiento5(){return Asiento5;}
    public Boolean getAsiento6(){return Asiento6;}
    public Boolean getAsiento7(){return Asiento7;}
    public Boolean getAsiento8(){return Asiento8;}
    public Boolean getAsiento9(){return Asiento9;}
    public Boolean getAsiento10(){return Asiento10;}
    public Boolean getAsiento11(){return Asiento11;}
    public Boolean getAsiento12(){return Asiento12;}
    public Boolean getAsiento13(){return Asiento13;}
    public Boolean getAsiento14(){return Asiento14;}
    public Boolean getAsiento15(){return Asiento15;}
    public Boolean getAsiento16(){return Asiento16;}
    public Boolean getAsiento17(){return Asiento17;}
    
    public void setAsiento1(Boolean val){Asiento1 = val;}
    public void setAsiento2(Boolean val){Asiento2 = val;}
    public void setAsiento3(Boolean val){Asiento3 = val;}
    public void setAsiento4(Boolean val){Asiento4 = val;}
    public void setAsiento5(Boolean val){Asiento5 = val;}
    public void setAsiento6(Boolean val){Asiento6 = val;}
    public void setAsiento7(Boolean val){Asiento7 = val;}
    public void setAsiento8(Boolean val){Asiento8 = val;}
    public void setAsiento9(Boolean val){Asiento9 = val;}
    public void setAsiento10(Boolean val){Asiento10 = val;}
    public void setAsiento11(Boolean val){Asiento11 = val;}
    public void setAsiento12(Boolean val){Asiento12 = val;}
    public void setAsiento13(Boolean val){Asiento13 = val;}
    public void setAsiento14(Boolean val){Asiento14 = val;}
    public void setAsiento15(Boolean val){Asiento15 = val;}
    public void setAsiento16(Boolean val){Asiento16 = val;}
    public void setAsiento17(Boolean val){Asiento17 = val;}
}