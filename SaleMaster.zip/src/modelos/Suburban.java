/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Suburban {
    private final Integer ID_suburban;
    private Boolean Asiento1;
    private Boolean Asiento2;
    private Boolean Asiento3;
    private Boolean Asiento4;
    private Boolean Asiento5;
    private Boolean Asiento6;
    private Boolean Asiento7;
    private Boolean Asiento8;
    private Boolean Asiento9;
    private Boolean Asiento10;
    private Boolean Asiento11;
    private Boolean Asiento12;
    private Boolean Asiento13;
    private Boolean Asiento14;
    private Boolean Asiento15;
    private Boolean Asiento16;
    private Boolean Asiento17;
    /**
     * Contructor de la clase sin parametros de entrada.
     * Este constructo inicializa el parametro ID_suburban en null, y a todos los demas en false.
     */
    public Suburban(){
        ID_suburban = null;
        Asiento1 = false;
        Asiento2 = false;
        Asiento3 = false;
        Asiento4 = false;
        Asiento5 = false;
        Asiento6 = false;
        Asiento7 = false;
        Asiento8 = false;
        Asiento9 = false;
        Asiento10 = false;
        Asiento11 = false;
        Asiento12 = false;
        Asiento13 = false;
        Asiento14 = false;
        Asiento15 = false;
        Asiento16 = false;
        Asiento17 = false;
    }
    /**
     * Constructor de la clase con parametros de entrada.
     * @param id El parametro id, es un entero con el numero de identificacion de la suburban.
     * @param a1 El parametro a1, es un booleano con el estado del asiento(comprado/libre).
     * @param a2 El parametro a2, es un booleano con el estado del asiento(comprado/libre).
     * @param a3 El parametro a3, es un booleano con el estado del asiento(comprado/libre).
     * @param a4 El parametro a4, es un booleano con el estado del asiento(comprado/libre).
     * @param a5 El parametro a5, es un booleano con el estado del asiento(comprado/libre).
     * @param a6 El parametro a6, es un booleano con el estado del asiento(comprado/libre).
     * @param a7 El parametro a7, es un booleano con el estado del asiento(comprado/libre).
     * @param a8 El parametro a8, es un booleano con el estado del asiento(comprado/libre).
     * @param a9 El parametro a9, es un booleano con el estado del asiento(comprado/libre).
     * @param a10 El parametro a10, es un booleano con el estado del asiento(comprado/libre).
     * @param a11 El parametro a11, es un booleano con el estado del asiento(comprado/libre).
     * @param a12 El parametro a12, es un booleano con el estado del asiento(comprado/libre).
     * @param a13 El parametro a13, es un booleano con el estado del asiento(comprado/libre).
     * @param a14 El parametro a14, es un booleano con el estado del asiento(comprado/libre).
     * @param a15 El parametro a15, es un booleano con el estado del asiento(comprado/libre).
     * @param a16 El parametro a16, es un booleano con el estado del asiento(comprado/libre).
     * @param a17 El parametro a17, es un booleano con el estado del asiento(comprado/libre).
     */
    public Suburban(Integer id,Boolean a1,Boolean a2,
                        Boolean a3,Boolean a4,Boolean a5,
                        Boolean a6,Boolean a7,Boolean a8,
                        Boolean a9,Boolean a10,Boolean a11,
                        Boolean a12,Boolean a13,Boolean a14,
                        Boolean a15,Boolean a16,Boolean a17){
        ID_suburban = id;
        Asiento1 = a1;
        Asiento2 = a2;
        Asiento3 = a3;
        Asiento4 = a4;
        Asiento5 = a5;
        Asiento6 = a6;
        Asiento7 = a7;
        Asiento8 = a8;
        Asiento9 = a9;
        Asiento10 = a10;
        Asiento11 = a11;
        Asiento12 = a12;
        Asiento13 = a13;
        Asiento14 = a14;
        Asiento15 = a15;
        Asiento16 = a16;
        Asiento17 = a17;
    }
    /**
     * Metodo que devuelve ID_suburban.
     * @return devuelve el numero de identificacion de la suburban.
     */
    public Integer getID_suburban(){return ID_suburban;}
    /**
     * Metodo que devuelve Asiento1.
     * @return devuelve el estado del asiento 1 (Vendido/libre).
     */
    public Boolean getAsiento1(){return Asiento1;}
    /**
     * Metodo que devuelve Asiento2.
     * @return devuelve el estado del asiento 2 (Vendido/libre).
     */
    public Boolean getAsiento2(){return Asiento2;}
    /**
     * Metodo que devuelve Asiento3.
     * @return devuelve el estado del asiento 3 (Vendido/libre).
     */
    public Boolean getAsiento3(){return Asiento3;}
    /**
     * Metodo que devuelve Asiento4.
     * @return devuelve el estado del asiento 4 (Vendido/libre).
     */
    public Boolean getAsiento4(){return Asiento4;}
    /**
     * Metodo que devuelve Asiento5.
     * @return devuelve el estado del asiento 5 (Vendido/libre).
     */
    public Boolean getAsiento5(){return Asiento5;}
    /**
     * Metodo que devuelve Asiento6.
     * @return devuelve el estado del asiento 6 (Vendido/libre).
     */
    public Boolean getAsiento6(){return Asiento6;}
    /**
     * Metodo que devuelve Asiento7.
     * @return devuelve el estado del asiento 7 (Vendido/libre).
     */
    public Boolean getAsiento7(){return Asiento7;}
    /**
     * Metodo que devuelve Asiento8.
     * @return devuelve el estado del asiento 8 (Vendido/libre).
     */
    public Boolean getAsiento8(){return Asiento8;}
    /**
     * Metodo que devuelve Asiento9.
     * @return devuelve el estado del asiento 9 (Vendido/libre).
     */
    public Boolean getAsiento9(){return Asiento9;}
    /**
     * Metodo que devuelve Asiento10.
     * @return devuelve el estado del asiento 10 (Vendido/libre).
     */
    public Boolean getAsiento10(){return Asiento10;}
    /**
     * Metodo que devuelve Asiento11.
     * @return devuelve el estado del asiento 11 (Vendido/libre).
     */
    public Boolean getAsiento11(){return Asiento11;}
    /**
     * Metodo que devuelve Asiento12.
     * @return devuelve el estado del asiento 12 (Vendido/libre).
     */
    public Boolean getAsiento12(){return Asiento12;}
    /**
     * Metodo que devuelve Asiento13.
     * @return devuelve el estado del asiento 13 (Vendido/libre).
     */
    public Boolean getAsiento13(){return Asiento13;}
    /**
     * Metodo que devuelve Asiento14.
     * @return devuelve el estado del asiento 14 (Vendido/libre).
     */
    public Boolean getAsiento14(){return Asiento14;}
    /**
     * Metodo que devuelve Asiento15.
     * @return devuelve el estado del asiento 15 (Vendido/libre).
     */
    public Boolean getAsiento15(){return Asiento15;}
    /**
     * Metodo que devuelve Asiento16.
     * @return devuelve el estado del asiento 16 (Vendido/libre).
     */
    public Boolean getAsiento16(){return Asiento16;}
    /**
     * Metodo que devuelve Asiento17.
     * @return devuelve el estado del asiento 17 (Vendido/libre).
     */
    public Boolean getAsiento17(){return Asiento17;}
    /**
     * Metodo que asigna el estado del asiento 1.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento1(Boolean val){Asiento1 = val;}
    /**
     * Metodo que asigna el estado del asiento 2.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento2(Boolean val){Asiento2 = val;}
    /**
     * Metodo que asigna el estado del asiento 3.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento3(Boolean val){Asiento3 = val;}
    /**
     * Metodo que asigna el estado del asiento 4.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento4(Boolean val){Asiento4 = val;}
    /**
     * Metodo que asigna el estado del asiento 5.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento5(Boolean val){Asiento5 = val;}
    /**
     * Metodo que asigna el estado del asiento 6.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento6(Boolean val){Asiento6 = val;}
    /**
     * Metodo que asigna el estado del asiento 7.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento7(Boolean val){Asiento7 = val;}
    /**
     * Metodo que asigna el estado del asiento 8.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento8(Boolean val){Asiento8 = val;}
    /**
     * Metodo que asigna el estado del asiento 9.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento9(Boolean val){Asiento9 = val;}
    /**
     * Metodo que asigna el estado del asiento 10.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento10(Boolean val){Asiento10 = val;}
    /**
     * Metodo que asigna el estado del asiento 11.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento11(Boolean val){Asiento11 = val;}
    /**
     * Metodo que asigna el estado del asiento 12.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento12(Boolean val){Asiento12 = val;}
    /**
     * Metodo que asigna el estado del asiento 13.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento13(Boolean val){Asiento13 = val;}
    /**
     * Metodo que asigna el estado del asiento 14.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento14(Boolean val){Asiento14 = val;}
    /**
     * Metodo que asigna el estado del asiento 15.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento15(Boolean val){Asiento15 = val;}
    /**
     * Metodo que asigna el estado del asiento 16.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento16(Boolean val){Asiento16 = val;}
    /**
     * Metodo que asigna el estado del asiento 17.
     * @param val El parametro val, es un Booleano con el estado del asiento(vendido/libre).
     */
    public void setAsiento17(Boolean val){Asiento17 = val;}
}