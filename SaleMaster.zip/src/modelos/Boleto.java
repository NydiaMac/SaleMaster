/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Boleto {
    private final Integer ID_boleto;
    private Integer No_Asiento;
    private String Destino;
    private String Fecha;
    private String Hora;
    private Integer ID_suburban;
    
    public Boleto(){
        ID_boleto = null;
        No_Asiento = null;
        Destino = null;
        Fecha = null;
        Hora = null;
        ID_suburban = null;
    }
    public Boleto(Integer id_boleto,Integer asiento,String destino,String fecha,String hora,Integer id_suburban){
        ID_boleto = id_boleto;
        No_Asiento = asiento;
        Destino = destino;
        Fecha = fecha;
        Hora = hora;
        ID_suburban = id_suburban;
    }
    public Integer getID_boleto(){return ID_boleto;}
    public Integer getNo_Asiento(){return No_Asiento;}
    public String getDestino(){return Destino;}
    public String getFecha(){return Fecha;}
    public String getHora(){return Hora;}
    public Integer getID_suburban(){return ID_suburban;}
    public void setNo_Asiento(Integer asiento){No_Asiento = asiento;}
    public void setDestino(String destino){Destino = destino;}
    public void setFecha(String fecha){Fecha = fecha;}
    public void setHora(String hora){Hora = hora;}
    public void setID_suburban(Integer id_suburban){ID_suburban = id_suburban;}
}
