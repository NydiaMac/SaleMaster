/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Boleto {
    private final Integer ID_boleto;
    private Integer No_Asiento;
    private String Pasajero;
    private String Destino;
    private String Fecha;
    private String Hora;
    private Integer ID_suburban;
    /**
     * Constructor de la clase sin ningun parametro de enrada.
     * Este metodo inicializa todos los atributos de la clase en null.
     */
    public Boleto(){
        ID_boleto = null;
        No_Asiento = null;
        Pasajero = null;
        Destino = null;
        Fecha = null;
        Hora = null;
        ID_suburban = null;
    }
    /**
     * Contructor de la clase con parametros de entrada
     * @param id_boleto El parametro id_boleto, es un entero que representa el numero con el que se identificara cada boleto.
     * @param asiento El parametro asiento, es un entero que representa el numero del asiento al que esta asociado el boleto
     * @param destino El parametro destino, es unString que representa el nombre del lugar al que se tiene como destino.
     * @param fecha El parametro fecha, es un String con la fecha de salida de la suburban en la que se el pasajero viajara.
     * @param hora El parametro hora, es un String con la hora en la que la suburban partira.
     * @param id_suburban El parametro id_suburban, es un entero que representa el numero con el que se identifica cada suburban
     * @param nombre El parametro nombre, es un String que represena el nombre del pasajero.
     */
    public Boleto(Integer id_boleto,Integer asiento,String destino,String fecha,String hora,Integer id_suburban,String nombre){
        ID_boleto = id_boleto;
        No_Asiento = asiento;
        Pasajero = nombre;
        Destino = destino;
        Fecha = fecha;
        Hora = hora;
        ID_suburban = id_suburban;
    }
    /**
     * Metodo que devuelve ID_voleto.
     * @return  el numero de identificacion del boleto.
     */
    public Integer getID_boleto(){return ID_boleto;}
    /**
     * Metodo que devuelve No_Asiento.
     * @return el numero del asiento asignado al boleto.
     */
    public Integer getNo_Asiento(){return No_Asiento;}
    /**
     * Metodo que devuelve Pasajero.
     * @return devuelve el nombre del pasajero que el boleto tiene asignado.
     */
    public String getPasajero(){return Pasajero;}
    /**
     * Metodo que devuelve Destino.
     * @return devuelve el destino que esta asociado con el boleto.
     */
    public String getDestino(){return Destino;}
    /**
     * Metodo que devuelve Fecha.
     * @return devuelve la fecha de la salida asociada al boleto.
     */
    public String getFecha(){return Fecha;}
    /**
     * Metodo que devuelve Hora.
     * @return devuelve la hora de salida de la suburban, asociada al boleto.
     */
    public String getHora(){return Hora;}
    /**
     * Metodo que devuelve ID_suburban.
     * @return devuelve el numero de identificacion de la suburban, la cual esta asociada con el boleto.
     */
    public Integer getID_suburban(){return ID_suburban;}
    /**
     * Metodo que asigna el numero de asiento al atributo No_Asiento.
     * @param asiento El parametro asiento, es un entero con el numero de asiento estara asociado al boleto.
     */
    public void setNo_Asiento(Integer asiento){No_Asiento = asiento;}
    /**
     * Metodo que asigna el nombre del pasajero al atributo Pasajero.
     * @param pas El parametro pas, es un String con el nombre del pasajero.
     */
    public void setPasajero(String pas){Pasajero = pas;}
    /**
     * Metodo que asigna el destino al atributo Destino.
     * @param destino El parametro destino, es un String con el nombre del lugar que se tiene como destino.
     */
    public void setDestino(String destino){Destino = destino;}
    /**
     * Metodo que asigna la fecha al atributo Fecha,
     * @param fecha El parametro fecha, es un String con la fecha de partida de la suburban.
     */
    public void setFecha(String fecha){Fecha = fecha;}
    /**
     * Metodo que asigna la hora al atributo Hora.
     * @param hora El parametro hora, es un String con la hora de partida de la suburban.
     */
    public void setHora(String hora){Hora = hora;}
    /**
     * Metodo que asigna el numero de identificacion al atributo ID_suburban.
     * @param id_suburban El parametro id_suburban, es un entero con el numero de identificacion de la suburban.
     */
    public void setID_suburban(Integer id_suburban){ID_suburban = id_suburban;}
}