/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Boleto {
    private final Integer ID_boleto;
    private Integer Asiento;
    private String Destino;
    private String Fecha;
    private String Hora;
    
    public Boleto(){
        ID_boleto = null;
        Asiento = null;
        Destino = null;
        Fecha = null;
        Hora = null;
    }
    public Boleto(Integer id_boleto,Integer asiento,String destino,String fecha,String hora){
        ID_boleto = id_boleto;
        Asiento = asiento;
        Destino = destino;
        Fecha = fecha;
        Hora = hora;
    }
    public Integer getID_boleto(){return ID_boleto;}
    public Integer getAsiento(){return Asiento;}
    public String getDestino(){return Destino;}
    public String getFecha(){return Fecha;}
    public String getHora(){return Hora;}
    public void setAsiento(Integer asiento){Asiento = asiento;}
    public void setDestino(String destino){Destino = destino;}
    public void setFecha(String fecha){Fecha = fecha;}
    public void setHora(String hora){Hora = hora;}
}
