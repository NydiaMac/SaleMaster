/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Empleado {
   private final Integer id_empleado;
   private String nombre;
   private String tipo;
   private String domicilio;
   private String localidad;
   private String telefono;
   private String CP;
   private String sexo;
   private String estado_civil;
   private String nacionalidad;
   private String Fecha_nacimiento;
   /**
    * Constructor de la clase sin ningun parametro de entrada.
    * Este metodo inicializa todos los atribuos en null.
    */
   public Empleado(){
       this.id_empleado = null;
       this.nombre=null;
       this.tipo=null;
       this.domicilio=null;
       this.localidad=null;
       this.telefono=null;
       this.CP=null;
       this.sexo=null;
       this.estado_civil=null;
       this.nacionalidad=null;
       this.Fecha_nacimiento=null;
   }
   /**
    * Contructor de la clase que recibe parametros de entrada.
    * @param id_empleado El parametro id_empleado, es un entero con el numero de identificacion del empleado.
    * @param nombre El parametro nombre, es un String con el nombre del empleado.
    * @param tipo El parametro tipo, es un String con el tipo de empleado(Vendedor, chofer/conductor).
    * @param domicilio El parametro domicilio, es un String con la direccion del empleado.
    * @param localidad El parametro localidad, es un String con la localidad en la que recide el empleado.
    * @param telefono El parametro telefono, es un Strinf con el numero telefonico del empleado.
    * @param CP El parametro CP, es un String con el Codigo postal del empleado.
    * @param sexo El parametro sexo, es un String con el sexo del empleado(Masculino/Femenino).
    * @param estado_civil El parametro estado_civil, es un String con el estado civil(Casado(a)/Soltero(a)) del empleado.
    * @param nacionalidad El parametro nacionalidad, es un String con la nacionalidad del empleado.
    * @param Fecha_nacimiento  El parametro Fecha_nacimieno, es un String con la fecha de nacimiento del empleado.
    */
   public Empleado(Integer id_empleado,String nombre,String tipo,String domicilio,String localidad,String telefono,String CP,String sexo,String estado_civil,String nacionalidad,String Fecha_nacimiento){
       this.id_empleado = id_empleado;
       this.nombre= nombre;
       this.tipo=tipo;
       this.domicilio=domicilio;
       this.localidad=localidad;
       this.telefono=telefono;
       this.CP=CP;
       this.sexo=sexo;
       this.estado_civil=estado_civil;
       this.nacionalidad=nacionalidad;
       this.Fecha_nacimiento=Fecha_nacimiento;
   }
   /**
    * Metodo que devuelve id_empleado.
    * @return devuelve el numero de identificacion del empleado.
    */
   public Integer getId_empleado(){
       return id_empleado;
   }
   /**
    * Metodo que devuelve nombre.
    * @return devuelve el nombre del empleado.
    */
   public String getNombre(){
       return nombre;
   }
   /**
    * Metodo que devuelve tipo.
    * @return devuelve el tipo de empleado(vendedor,chofer/conductor).
    */
   public String getTipo(){
       return tipo;
   }
   /**
    * Metodo que devuelve domicilio.
    * @return devuelve el domicilio del empleado.
    */
   public String getDomicilio(){
       return domicilio;
   }
   /**
    * Metodo que devuelve localidad.
    * @return devuelve la localidad en la que recide el empleado.
    */
   public String getLocalidad(){
       return localidad;
   }
   /**
    * Metodo que devuelve telefono.
    * @return devuelve el numero telefonico del empleado.
    */
   public String getTelefono(){
       return telefono;
   }
   /**
    * Metodo que devuelve CP.
    * @return devuelve el Codigo postal del empleado.
    */
   public String getCP(){
       return CP;
   }
   /**
    * Metodo que devuelve sexo.
    * @return devuelve el sexo(Masculino/Femenino) del empleado.
    */
   public String getSexo(){
       return sexo;
   }
   /**
    * Metodo que devuelve estado_civil.
    * @return devuelve el estado civil del empleado(casado(a)/Soltero(a)).
    */
   public String getEstado_civil(){
       return estado_civil;
   }
   /**
    * Metodo que devuelve nacionalidad.
    * @return devuelve la nacionalidad del empleado.
    */
   public String getNacionalidad(){
       return nacionalidad;
   }
   /**
    * Metodo que devuelve Fecha_nacimiento.
    * @return devuelve la fecha de nacimiento del empleado.
    */
   public String getFecha_nacimiento(){
       return Fecha_nacimiento;
   }
   /**
    * Metodo que asigna nombre al atributo nombre.
    * @param nombre El parametro nombre, es un String con el nimbre del usuario.
    */
   public void setNombre(String nombre){
       this.nombre= nombre;
   }
   /**
    * Metodo que asigna tipo al empleado.
    * @param tipo El parametro tipo, es un String con el tipo de empleado(vendedor,chofer/conductor).
    */
   public void setTipo(String tipo){
       this.tipo=tipo;
   }
   /**
    * Metodo que asigna domicilio al empleado.
    * @param domicilio El parametro domicilio, es un String con el domicilio del empleado.
    */
   public void setDomicilio(String domicilio){
       this.domicilio=domicilio;
   }
   /**
    * Metodo que asigna la localidad al empleado.
    * @param localidad El atributo localidad, es un String, con el nombre de la localidad en la que el empleado recide.
    */
   public void setLocalidad(String localidad){
       this.localidad=localidad;
   }
   /**
    * Metodo que asigna numero telefonico al empleado.
    * @param telefono El parametro telefono, es un String ccon el numero telefonico del empleado.
    */
   public void setTelefono(String telefono){
       this.telefono=telefono;
   }
   /**
    * Metodo que asigna codigo postal al empleado.
    * @param CP El parametro CP, es un String con el numero de codigo postal del empleado.
    */
   public void setCP(String CP){
       this.CP=CP;
   }
   /**
    * Metodo que asigna el sexo al empleado.
    * @param sexo El parametro sexo, es un String con el sexo(Masculino/Femenino) del empleado.
    */
   public void setSexo(String sexo){
       this.sexo=sexo;
   }
   /**
    * Metodo que asigna el estado civil al empleado.
    * @param estado_civil El parametro estado_civil, es un String con el estado civil del empleado.
    */
   public void setEstado_civil(String estado_civil){
       this.estado_civil=estado_civil;
   }
   /**
    * Metodo que asigna la nacionalidad al empleado.
    * @param nacionalidad El prametro nacionalidad, es un String con la naionalidad del empleado.
    */
   public void setNacionalidad(String nacionalidad){
       this.nacionalidad=nacionalidad;
   }
   /**
    * Metodo que asigna la fecha de nacimiento al empleado.
    * @param Fecha_nacimiento El parametro Fecha_nacimiento, es un String con la fecha de nacimiento del empleado.
    */
   public void setFecha_nacimiento(String Fecha_nacimiento){
       this.Fecha_nacimiento=Fecha_nacimiento;
   }
}
