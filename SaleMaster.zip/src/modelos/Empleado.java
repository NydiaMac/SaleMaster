/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author juan
 */
public class Empleado {
   private final Integer id_empleado;
   private String nombre;
   private String tipo;
   private String domicilio;
   private String localidad;
   private String telefono;
   private String CP;
   private String sexo;
   private String estado_civil;
   private String nacionalidad;
   private String Fecha_nacimiento;
   
   public Empleado(){
       this.id_empleado = null;
       this.nombre=null;
       this.tipo=null;
       this.domicilio=null;
       this.localidad=null;
       this.telefono=null;
       this.CP=null;
       this.sexo=null;
       this.estado_civil=null;
       this.nacionalidad=null;
       this.Fecha_nacimiento=null;
   }
   public Empleado(Integer id_empleado,String nombre,String tipo,String domicilio,String localidad,String telefono,String CP,String sexo,String estado_civil,String nacionalidad,String Fecha_nacimiento){
       this.id_empleado = id_empleado;
       this.nombre= nombre;
       this.tipo=tipo;
       this.domicilio=domicilio;
       this.localidad=localidad;
       this.telefono=telefono;
       this.CP=CP;
       this.sexo=sexo;
       this.estado_civil=estado_civil;
       this.nacionalidad=nacionalidad;
       this.Fecha_nacimiento=Fecha_nacimiento;
   }
   public Integer getId_empleado(){
       return id_empleado;
   }
   public String getNombre(){
       return nombre;
   }
   public String getTipo(){
       return tipo;
   }
   public String getDomicilio(){
       return domicilio;
   }
   public String getLocalidad(){
       return localidad;
   }
   public String getTelefono(){
       return telefono;
   }
   public String getCP(){
       return CP;
   }
   public String getSexo(){
       return sexo;
   }
   public String getEstado_civil(){
       return estado_civil;
   }
   public String getNacionalidad(){
       return nacionalidad;
   }
   public String getFecha_nacimiento(){
       return Fecha_nacimiento;
   }  
   public void setNombre(String nombre){
       this.nombre= nombre;
   }
   public void setTipo(String tipo){
       this.tipo=tipo;
   }
   public void setDomicilio(String domicilio){
       this.domicilio=domicilio;
   }
   public void setLocalidad(String localidad){
       this.localidad=localidad;
   }
   public void setTelefono(String telefono){
       this.telefono=telefono;
   }
   public void setCP(String CP){
       this.CP=CP;
   }
   public void setSexo(String sexo){
       this.sexo=sexo;
   }
   public void setEstado_civil(String estado_civil){
       this.estado_civil=estado_civil;
   }
   public void setNacionalidad(String nacionalidad){
       this.nacionalidad=nacionalidad;
   }
   public void setFecha_nacimiento(String Fecha_nacimiento){
       this.Fecha_nacimiento=Fecha_nacimiento;
   }
}
