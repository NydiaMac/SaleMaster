/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author alumnos
 */
public class PaqueteriaDatos {
    private String Remitente;
    private String Destinatario;
    private String Descripcion;
    private Integer Npaquetes;
    private Float Peso;
    private final Integer Codigo;
    private Float Importe;
    private String origen;
    private String destino;
    private String fecha;
    private String Unidad;
    private String chofer;
    private String Entregado;
    

    
    public PaqueteriaDatos(){
        Remitente = null;
        Destinatario =null;
        Descripcion=null;
        Npaquetes = null;
        Peso=null;
        Codigo = null;
        Importe= null;
        origen=null;
        destino=null;
        fecha=null;
        Unidad=null;
        chofer=null;
        Entregado =null;
    } 
    
    
    public PaqueteriaDatos(String R, String D,String Des,Integer NP,float p,Integer C,float I,String o,String d,String f,String U,String Ch,String E ){
        this.Remitente=R;
        this.Destinatario=D;
        this.Descripcion=Des;
        this.Npaquetes=NP;
        this.Peso=p;
        this.Codigo=C;
        this.Importe=I;
        this.origen=o;
        this.destino=d;
        this.fecha=f;
        this.Unidad=U;
        this.chofer=Ch;
        this.Entregado=E;   
    }
    
    public void setRemitente(String R){
        this.Remitente=R;
    }
    
    public void setDestinatario(String D){
        this.Destinatario=D;
    }
    
    public void setDescrpcion(String Des){
        this.Descripcion=Des;
    }
    
    public void setNpaquetes(Integer NP){
        this.Npaquetes=NP;
    }
    
    public void setPeso(float p){
        this.Peso=p;
    }
    
    public void setImporte(float I){
        this.Importe=I;
    }
    
    public void setOrigen(String o){
        this.origen=o;
    }
    
    public void setDestino(String d){
        this.destino=d;
    }
    
    public void setUnidad(String u){
        this.Unidad=u;
    }

    public void setChofer(String Ch){
        this.chofer=Ch;
    }
    
    public void setEntregado(String E){
        this.Entregado=E;
    }
    public void setFecha(String f){
        this.fecha=f;
    }
    
    public String getRemitente(){
        return Remitente;
    }
        
    public String getFecha(){
        return fecha;
    }
    
    public String getDestinatario(){
        return Destinatario;
    }
    
    public String getDescripcion(){
        return Descripcion;
    }
    
    public String getOrigen(){
        return origen;
    }
    
    public Float getPeso(){
        return Peso;
    }
    public String getDestino(){
        return destino;
    }
    
    public String getUnidad(){
        return Unidad;
    }
    
    public String getChofer(){
        return chofer;
    }
    
    public Integer getNpaquetes(){
        return Npaquetes;
    }
    
    public Integer getCodigo(){
        return Codigo;
    }
    
    public Float getImporte(){
        return Importe;
    }
    
    
    public String getEntregado(){
        return Entregado;
    }
        
}
