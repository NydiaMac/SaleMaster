/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author Benitez
 */
public class PaqueteriaDatos {
    private String Remitente;
    private String Destinatario;
    private String Descripcion;
    private Integer Npaquetes;
    private Float Peso;
    private final Integer Codigo;
    private Float Importe;
    private String origen;
    private String destino;
    private String fecha;
    private String Unidad;
    private String chofer;
    private String Entregado;
    
    /**
     * Constructor de la clase sin parametros de entrada.
     * Este metodo inicializa a todos los atributos de la clase.
     */
    public PaqueteriaDatos(){
        Remitente = null;
        Destinatario =null;
        Descripcion=null;
        Npaquetes = null;
        Peso=null;
        Codigo = null;
        Importe= null;
        origen=null;
        destino=null;
        fecha=null;
        Unidad=null;
        chofer=null;
        Entregado =null;
    } 
    
    /**
     * Constructor de la clase con parametros de entrada.
     * @param R El paramero R, es un String con el nombre del remitente.
     * @param D El parametro D, es un String con el nombre del destinatario.
     * @param Des El parametro Des, es un String con la descripcion del paquete.
     * @param NP El parametro NP, es un entero con el numero de paquetes.
     * @param p El parametro p, es un floatante con el peso del paquete o paquetes.
     * @param C El parametro C, es un entero con el numero de identificacion del paquete.
     * @param I El parametro I, es un flotante con el importe por el envio.
     * @param o El parametro o, es un String con el nombre del lugar de donde se envia el paquete.
     * @param d El parametro d, es un String con el nombre del lugar de destino.
     * @param f El parametro fecha, es un String con la fecha en la que se realiza el envio.
     * @param U El parametro U, es un String con el numero de la unidad en la que se enviara el paquete.
     * @param Ch El parametro Ch, es un String con el nombre del chofer de la suburban.
     * @param E El parametro E es un String que servira para saber si el paquete ya se ha entregado o no.
     */
    public PaqueteriaDatos(String R, String D,String Des,Integer NP,float p,Integer C,float I,String o,String d,String f,String U,String Ch,String E ){
        this.Remitente=R;
        this.Destinatario=D;
        this.Descripcion=Des;
        this.Npaquetes=NP;
        this.Peso=p;
        this.Codigo=C;
        this.Importe=I;
        this.origen=o;
        this.destino=d;
        this.fecha=f;
        this.Unidad=U;
        this.chofer=Ch;
        this.Entregado=E;   
    }
    /**
     * Metodo que asigna el remitente al envio.
     * @param R El paramtro R, es un String con el nombre del remietente.
     */
    public void setRemitente(String R){
        this.Remitente=R;
    }
    /**
     * Metodo que asigna el destinatario al envio.
     * @param D El parametro D, es un String con el nombre del destinatario.
     */
    public void setDestinatario(String D){
        this.Destinatario=D;
    }
    /**
     * Metodo que le asigna la descripcion al paquete.
     * @param Des El parametro Des, es un String con la descripcion del envio.
     */
    public void setDescrpcion(String Des){
        this.Descripcion=Des;
    }
    /**
     * Metodo que asigna el Numero de qauetes al envio
     * @param NP 
     */
    public void setNpaquetes(Integer NP){
        this.Npaquetes=NP;
    }
    /**
     * Metodo que le asigna el peso al envio.
     * @param p El parametro p, es un flortante con el peso del envio.
     */
    public void setPeso(float p){
        this.Peso=p;
    }
    /**
     * Metodo que asigna el importe al envio.
     * @param I El parametro I, es un flotante con el importe del envio.
     */
    public void setImporte(float I){
        this.Importe=I;
    }
    /**
     * Metodo que le asigna el lugar de origen al envio.
     * @param o El parametro o, es un String con el nombre del lugar de origen del envio.
     */
    public void setOrigen(String o){
        this.origen=o;
    }
    /**
     * Metodo que signa el destino al envio.
     * @param d El parametro d, es un String con el nombre del lugar de destino.
     */
    public void setDestino(String d){
        this.destino=d;
    }
    /**
     * Metodo que asigna el numero de la suburban en la que se enviara el paquete.
     * @param u El parametro u, es un String con el numero de la suburban.
     */
    public void setUnidad(String u){
        this.Unidad=u;
    }
    /**
     * Metodo para asignar el chofer de la suburban en la que se realizara el envio.
     * @param Ch El parametro Ch, es un String con el nombre del chofer de la suburban.
     */
    public void setChofer(String Ch){
        this.chofer=Ch;
    }
    /**
     * Metodo para asignar el estado del envio(si fue entregado o aun no).
     * @param E El parametro E, es un string con el estado del paquete(entregado o no).
     */
    public void setEntregado(String E){
        this.Entregado=E;
    }
    /**
     * Metodo para asignar la fecha del envio.
     * @param f El parametro f, es un String con la fecha en la que se realizo el envio.
     */
    public void setFecha(String f){
        this.fecha=f;
    }
    /**
     * Metodo que devuelve Remitente.
     * @return devuelve el nombre del remitente.
     */
    public String getRemitente(){
        return Remitente;
    }
    /**
     * Metodo que devuelve fecha.
     * @return devuelve la fecha en la que se realizo el envio.
     */
    public String getFecha(){
        return fecha;
    }
    /**
     *Metodo que devuelve Destinatario. 
     * @return devuelve el nombre del destinatario.
     */
    public String getDestinatario(){
        return Destinatario;
    }
    /**
     * Metodo que devuelve Descripcion.
     * @return devuelve la descripcion del envio.
     */
    public String getDescripcion(){
        return Descripcion;
    }
    /**
     * Metodo que devuelve origen.
     * @return devuelve el nombre del lugar de origen del envio.
     */
    public String getOrigen(){
        return origen;
    }
    /**
     * Metodo que devuelve Peso.
     * @return devuelve el peso del envio.
     */
    public Float getPeso(){
        return Peso;
    }
    /**
     * Metodo que devuelve destino.
     * @return devuelve el nombre del lugar de desino del envio.
     */
    public String getDestino(){
        return destino;
    }
    /**
     * Metodo que devuelve Unidad. 
     * @return devulve el numero de la unidad en la que se reliza el envio.
     */
    public String getUnidad(){
        return Unidad;
    }
    /**
     * Metofo que devuelve chofer.
     * @return devuelve el nombre del chofer.
     */
    public String getChofer(){
        return chofer;
    }
    /**
     * Metodo que devuelve Npaquetes. 
     * @return devuelve el numero de paquetes del envio.
     */
    public Integer getNpaquetes(){
        return Npaquetes;
    }
    /**
     * Metodo que devuelve Codigo.
     * @return devuelve el codigo de envio.
     */
    public Integer getCodigo(){
        return Codigo;
    }
    /**
     * Metodo que devuelve Importe.
     * @return devuelve el importe del envio.
     */
    public Float getImporte(){
        return Importe;
    }
    /**
     * Metodo que devuelve Entregado.
     * @return devuelve el estado del envio (si fue entrgado o no).
     */
    public String getEntregado(){
        return Entregado;
    }
        
}
