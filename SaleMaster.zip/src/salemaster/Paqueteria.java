/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salemaster;

import java.awt.event.ActionEvent;
import java.sql.SQLException;
import modelos.PaqueteriaDatos;
import servicios.Paquetes_servicios;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import servicios.Conexion;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumnos
 */
public class Paqueteria extends javax.swing.JFrame {
    private final Paquetes_servicios paquetes_servicio = new Paquetes_servicios();
    private final PaqueteriaDatos Paquete;
    private List<PaqueteriaDatos> packs;
    /**
     * Creates new form Paqueteria
     */
    public Paqueteria() {
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.Paquete = new PaqueteriaDatos();
        initComponents();
        this.cargar_lista_paquetes();
        this.cargar_lista_paquetesEntregados();
        bloquear();
    }
    
    public Paqueteria(PaqueteriaDatos P_Paqueteria){
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.Paquete= P_Paqueteria;
        initComponents();
        this.cargar_lista_paquetes();
        this.cargar_lista_paquetesEntregados();
        origen.setSelectedItem(this.Paquete.getOrigen());
        destino.setSelectedItem(this.Paquete.getDestino());
        unidad.setSelectedItem(this.Paquete.getUnidad());
        Remitente.setText(this.Paquete.getRemitente());
        chofer.setSelectedItem(this.Paquete.getChofer());
        fecha.setSelectedItem(this.Paquete.getFecha());
        Peso.setText(this.Paquete.getPeso().toString());
        Destinatario.setText(this.Paquete.getDestinatario());
        remitente.setText(this.Paquete.getRemitente());
        Destinatario.setText(this.Paquete.getDestinatario());
        Paquetes.setText(this.Paquete.getNpaquetes().toString());
        Descripcion.setText(this.Paquete.getDescripcion());
        Codigo.setText(this.Paquete.getCodigo().toString());
        Importe.setText(this.Paquete.getImporte().toString());
        //Entregado.setText(this.Paquete.getEntregado());
        
    }
    
    

    public void limpiar(){
        Remitente.setText(" ");
        Destinatario.setText(" ");
        Descripcion.setText(" ");
        Paquetes.setText(" ");
        Peso.setText(" ");
        Codigo.setText(" ");
        Importe.setText(" ");
        origen.setToolTipText(" ");
        destino.setToolTipText("");
        fecha.setToolTipText("");
        unidad.setToolTipText("");
        chofer.setToolTipText("");
    }
    public void bloquear(){
        Importe.setEnabled(false);
        Codigo.setEnabled(false);
    }
    
    public float Calcular(float p,String des){    
        return p;
    }
    private void cargar_lista_paquetes(PaqueteriaDatos Pack){
        DefaultTableModel dtm = (DefaultTableModel) tentrega.getModel();
        dtm.setRowCount(0);
        dtm.addRow(new Object[]{
            Pack.getRemitente(),
            Pack.getDestinatario(),
            Pack.getNpaquetes(),
            Pack.getImporte(),
            Pack.getCodigo(),
            Pack.getEntregado()
            });
    }
    private void cargar_lista_paquetes(){
        try{
            this.packs = this.paquetes_servicio.recuperarTodas(Conexion.obtener());
            DefaultTableModel dtm = (DefaultTableModel) tentrega.getModel();
            dtm.setRowCount(0);
            for(int i = 0; i < this.packs.size(); i++){
                if(this.packs.get(i).getEntregado().indexOf("No")!=-1)
                    dtm.addRow(new Object[]{
                        this.packs.get(i).getRemitente(),
                        this.packs.get(i).getDestinatario(),
                        this.packs.get(i).getNpaquetes(),
                        this.packs.get(i).getImporte(),
                        this.packs.get(i).getCodigo(),
                        this.packs.get(i).getEntregado()
                });
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se han podido recuperar los registros");
        }catch(ClassNotFoundException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se han podido recuperar los registros");
        }
    }
    private void cargar_lista_paquetesEntregados(){
        try{
            this.packs = this.paquetes_servicio.recuperarTodas(Conexion.obtener());
            DefaultTableModel dtm = (DefaultTableModel) trecibidos.getModel();
            dtm.setRowCount(0);
            for(int i = 0; i < this.packs.size(); i++){
                if(this.packs.get(i).getEntregado().indexOf("Si")!=-1)
                    dtm.addRow(new Object[]{
                        this.packs.get(i).getRemitente(),
                        this.packs.get(i).getDestinatario(),
                        this.packs.get(i).getNpaquetes(),
                        this.packs.get(i).getImporte(),
                        this.packs.get(i).getCodigo(),
                        this.packs.get(i).getEntregado()
                });
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se han podido recuperar los registros");
        }catch(ClassNotFoundException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se han podido recuperar los registros");
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelfondo = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        origen = new javax.swing.JComboBox<>();
        destino = new javax.swing.JComboBox<>();
        unidad = new javax.swing.JComboBox<>();
        chofer = new javax.swing.JComboBox<>();
        fecha = new javax.swing.JComboBox<>();
        Destinatario = new javax.swing.JTextField();
        peso = new java.awt.Label();
        remitente = new java.awt.Label();
        destinatario = new java.awt.Label();
        paquetes = new java.awt.Label();
        descripcion = new java.awt.Label();
        importe = new java.awt.Label();
        codigo = new java.awt.Label();
        Remitente = new javax.swing.JTextField();
        Peso = new javax.swing.JTextField();
        Paquetes = new javax.swing.JTextField();
        Importe = new javax.swing.JTextField();
        Codigo = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        Descripcion = new javax.swing.JTextPane();
        Calcular = new javax.swing.JButton();
        Realizar = new javax.swing.JButton();
        Nuevo = new javax.swing.JButton();
        TEntregados = new javax.swing.JTabbedPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        tentrega = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        trecibidos = new javax.swing.JTable();
        Buscar = new java.awt.TextField();
        bBuscar = new javax.swing.JButton();
        Entregar = new javax.swing.JButton();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Paqueteria-Sale-Master");
        setBackground(java.awt.Color.white);

        panelfondo.setBackground(new java.awt.Color(254, 254, 254));

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        origen.setBackground(java.awt.Color.white);
        origen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Origen", "Huajuapan", "Oaxaca", "Nochixtlan", "Tamazulapam" }));
        origen.setMinimumSize(new java.awt.Dimension(80, 30));
        origen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                origenActionPerformed(evt);
            }
        });

        destino.setBackground(java.awt.Color.white);
        destino.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Destino", "Oaxaca", "Nochixtlan", "Huajuapan", "Tamazulapam" }));
        destino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                destinoActionPerformed(evt);
            }
        });

        unidad.setBackground(java.awt.Color.white);
        unidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Suburban", "Unidad 1", "Unidad 2", "Unidad 3", "Unidad 4", " " }));
        unidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unidadActionPerformed(evt);
            }
        });

        chofer.setBackground(java.awt.Color.white);
        chofer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chofer", "Andres", "Juan", "Citlalli", "Nidia", "Navi", "Janeth", " " }));

        fecha.setBackground(java.awt.Color.white);
        fecha.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "10/06/2017", "11/06/2017", "12/06/2017", "13/06/2017", "14/06/2017", "15/06/2017" }));

        Destinatario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DestinatarioActionPerformed(evt);
            }
        });

        peso.setText("Peso en kg");

        remitente.setText("Remitente");

        destinatario.setText("Destinatario");

        paquetes.setText("Paquetes");

        descripcion.setText("Descripcion");

        importe.setText("Importe");

        codigo.setText("Codigo de envio");

        Remitente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemitenteActionPerformed(evt);
            }
        });

        Peso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PesoKeyTyped(evt);
            }
        });

        Paquetes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaquetesActionPerformed(evt);
            }
        });
        Paquetes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PaquetesKeyTyped(evt);
            }
        });

        Importe.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ImporteKeyTyped(evt);
            }
        });

        Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CodigoActionPerformed(evt);
            }
        });
        Codigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                CodigoKeyTyped(evt);
            }
        });

        jScrollPane2.setViewportView(Descripcion);

        Calcular.setBackground(new java.awt.Color(0, 135, 255));
        Calcular.setText("Calcular");
        Calcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalcularActionPerformed(evt);
            }
        });
        Entregar.setBackground(new java.awt.Color(0, 135, 255));
        Entregar.setText("Entregar");
        Entregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    EntregarActionPerformed(evt);
                } catch (SQLException ex) {
                    Logger.getLogger(Paqueteria.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Paqueteria.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        Realizar.setBackground(new java.awt.Color(23, 196, 221));
        Realizar.setText("Realizar");
        Realizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RealizarActionPerformed(evt);
            }
        });

        Nuevo.setBackground(new java.awt.Color(95, 189, 254));
        Nuevo.setText("Nuevo");
        Nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NuevoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(paquetes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(peso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Peso, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                                    .addComponent(Paquetes)))
                            .addComponent(origen, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(destino, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(unidad, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(chofer, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(454, 454, 454)
                                        .addComponent(importe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Importe, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(32, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(remitente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(1, 1, 1)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(Remitente, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(destinatario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(Destinatario, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(12, 12, 12)
                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(Nuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(Calcular, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(Entregar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18,18,18)
                                        .addComponent(Realizar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(destino, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(unidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(chofer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(origen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(destinatario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Remitente))
                    .addComponent(Peso, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(peso, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(remitente, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Destinatario, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Nuevo)
                                    .addComponent(Calcular)
                                    .addComponent(Entregar))
                                    
                                .addGap(0, 1, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(importe, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Importe, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(22, 22, 22))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Paquetes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paquetes, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Realizar)
                            .addComponent(Codigo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TEntregados.setBackground(new java.awt.Color(254, 254, 254));
        TEntregados.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tentrega.setBackground(new java.awt.Color(254, 254, 254));
        tentrega.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tentrega.setForeground(new java.awt.Color(10, 155, 206));
        tentrega.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Remitente", "Destinatario", "# Paquetes", "Importe", "Codigo de envio", "Entregado"
            }
        ));
        tentrega.setGridColor(new java.awt.Color(10, 0, 0));
        tentrega.setSelectionBackground(new java.awt.Color(24, 176, 253));
        jScrollPane3.setViewportView(tentrega);

        TEntregados.addTab("Enviados", jScrollPane3);

        trecibidos.setBackground(new java.awt.Color(254, 254, 254));
        trecibidos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        trecibidos.setForeground(new java.awt.Color(10, 155, 206));
        trecibidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Remitente", "Destinatario", "# Paquetes", "Importe", "Código de envío", "Enviado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        trecibidos.setSelectionBackground(new java.awt.Color(24, 176, 253));
        jScrollPane1.setViewportView(trecibidos);

        TEntregados.addTab("Entregados", jScrollPane1);

        Buscar.setBackground(new java.awt.Color(254, 254, 254));
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        bBuscar.setBackground(new java.awt.Color(1, 178, 226));
        bBuscar.setText("Buscar");
        bBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    bBuscarActionPerformed(evt);
                } catch (SQLException ex) {
                    Logger.getLogger(Paqueteria.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Paqueteria.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        javax.swing.GroupLayout panelfondoLayout = new javax.swing.GroupLayout(panelfondo);
        panelfondo.setLayout(panelfondoLayout);
        panelfondoLayout.setHorizontalGroup(
            panelfondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfondoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelfondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TEntregados)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelfondoLayout.createSequentialGroup()
                        .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bBuscar))
                    .addGroup(panelfondoLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelfondoLayout.setVerticalGroup(
            panelfondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfondoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelfondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TEntregados, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelfondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelfondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void destinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_destinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_destinoActionPerformed

    private void unidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unidadActionPerformed

    private void origenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_origenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_origenActionPerformed

    private void RemitenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemitenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RemitenteActionPerformed

    private void DestinatarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DestinatarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DestinatarioActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BuscarActionPerformed

    private void NuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevoActionPerformed
        limpiar(); 
    }//GEN-LAST:event_NuevoActionPerformed

    private void PaquetesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaquetesActionPerformed
        // TODO add your handling code he
    }//GEN-LAST:event_PaquetesActionPerformed
        
    private void CalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalcularActionPerformed
        String imp = Paquetes.getText();
        if(imp.equals(""))
            JOptionPane.showMessageDialog(this, "Operacion Invalida. No hay un numero de paquetes");
        else{
            Integer paq = Integer.parseInt(imp.trim());
            Integer aux = paq*((Integer)80);
            this.Importe.setText(aux.toString());
        }
    }//GEN-LAST:event_CalcularActionPerformed
    private void EntregarActionPerformed(java.awt.event.ActionEvent evt) throws SQLException, ClassNotFoundException{
        int packSelected = tentrega.getSelectedRow();
        if(packSelected >=0){
            int decision = JOptionPane.showConfirmDialog(null, "¿Está seguro/a que desea entregar este paquete?", "Advertencia", JOptionPane.YES_NO_OPTION);
            if(decision == 0){
                try{
                    PaqueteriaDatos pacc= this.packs.get(packSelected);
                    pacc.setEntregado("Si");
                    this.paquetes_servicio.guardar(Conexion.obtener(), pacc);
                }catch(SQLException ex){
                    System.out.println(ex.getMessage());
                    JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido registrar la entrega.");
                }catch(ClassNotFoundException ex){
                    System.out.println(ex);
                    JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido registrar la entrega.");
                }
            }
        }
        this.cargar_lista_paquetesEntregados();
        this.cargar_lista_paquetes();
    }
    private void CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CodigoActionPerformed

    private void RealizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RealizarActionPerformed

        if(this.validar()){
            this.registrarPaquete();
            this.cargar_lista_paquetes();
            this.cargar_lista_paquetesEntregados();
        }else{
            JOptionPane.showMessageDialog(this, "Hay campos incompletos.");
        }
        
        this.cargar_lista_paquetes();
        this.cargar_lista_paquetesEntregados();
        this.dispose();
        new Paqueteria().setVisible(true);
    }//GEN-LAST:event_RealizarActionPerformed

    private void PesoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PesoKeyTyped
        char c=evt.getKeyChar();
        
        if(Character.isLetter(c)){
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_PesoKeyTyped

    private void PaquetesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PaquetesKeyTyped
        char c=evt.getKeyChar();
        
        if(Character.isLetter(c)){
            getToolkit().beep();
            evt.consume();
         }
    }//GEN-LAST:event_PaquetesKeyTyped

    private void ImporteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ImporteKeyTyped
        char c=evt.getKeyChar();
        
        if(Character.isLetter(c)){
            getToolkit().beep();
            evt.consume();
         }
    }//GEN-LAST:event_ImporteKeyTyped

    private void CodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CodigoKeyTyped
        char c=evt.getKeyChar();
        
        if(Character.isLetter(c)){
            getToolkit().beep();
            evt.consume();
         }
    }//GEN-LAST:event_CodigoKeyTyped

    private void bBuscarActionPerformed(java.awt.event.ActionEvent evt) throws SQLException, ClassNotFoundException {//GEN-FIRST:event_bBuscarActionPerformed
        String Busqueda = Buscar.getText().trim();
        int id = Integer.parseInt(Busqueda);
        try{
            PaqueteriaDatos pack = this.paquetes_servicio.recuperarPorId(Conexion.obtener(), id);
            this.cargar_lista_paquetes(pack);
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido encontrar el paquete.");
        }catch(ClassNotFoundException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido encontrar el paquete.");
        }
    }//GEN-LAST:event_bBuscarActionPerformed
    private void formWindowClosed(java.awt.event.WindowEvent evt) {                                  
        // TODO add your handling code here:
    }  
    private void formWindowClosing(java.awt.event.WindowEvent evt) {                                   
        // TODO add your handling code here:
        try{
            Conexion.cerrar();
            System.out.println("Conexión cerrada.");
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
    }           
    private boolean validar(){
        boolean validado = true;
        String ori = origen.getSelectedItem().toString();
        String des = destino.getSelectedItem().toString();
        String uni = unidad.getSelectedItem().toString();
        String cho = chofer.getSelectedItem().toString();
        String fec = fecha.getSelectedItem().toString();
        Float pes;
        String rem = Remitente.getText();
        String dest = Destinatario.getText();
        Integer paq;
        String desc=Descripcion.getText();
        Float impo;
        
        if(!ori.trim().equals("Origen") && !des.trim().equals("Destino") && !uni.trim().equals("Suburban") && !cho.trim().equals("Chofer")&& !fec.trim().equals("") && !rem.trim().equals("") && !dest.trim().equals("") && !desc.trim().equals("")){
            try{
                String aux1 = Peso.getText();
                String aux2 = Paquetes.getText();
                String aux3 = Importe.getText();
                pes = Float.parseFloat(aux1.trim());
                paq = Integer.parseInt(aux2.trim());
                impo = Float.parseFloat(aux3.trim());
            }catch(NumberFormatException ex){
                validado = false;
            }
        }else{
            validado = false;
        }
        return validado;
    }
    
    private void registrarPaquete(){
        String ori = origen.getSelectedItem().toString();
        String des = destino.getSelectedItem().toString();
        String uni = unidad.getSelectedItem().toString();
        String cho = chofer.getSelectedItem().toString();
        String fec = fecha.getSelectedItem().toString();
        String aux1 = Peso.getText();
        String aux2 = Paquetes.getText();
        String aux3 = Importe.getText();
        Float   pes = Float.parseFloat(aux1.trim());
        Integer paq = Integer.parseInt(aux2.trim());
        Float impo = Float.parseFloat(aux3.trim());
        String rem = Remitente.getText();
        String dest = Destinatario.getText();
        String desc=Descripcion.getText();

        this.Paquete.setOrigen(ori);
        this.Paquete.setDestino(des);
        this.Paquete.setUnidad(uni);
        this.Paquete.setChofer(cho);
        this.Paquete.setFecha(fec);
        this.Paquete.setPeso(pes);
        this.Paquete.setRemitente(rem);
        this.Paquete.setDestinatario(dest);
        this.Paquete.setNpaquetes(paq);
        this.Paquete.setDescrpcion(desc);
        this.Paquete.setImporte(impo);
        this.Paquete.setEntregado("No");
        try{
            this.paquetes_servicio.guardar(Conexion.obtener(), this.Paquete);
            Paqueteria.this.dispose();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido guardar el registro.");
        }catch(ClassNotFoundException ex){
            System.out.println(ex);
            JOptionPane.showMessageDialog(this, "Ha surgido un error y no se ha podido guardar el registro.");
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Paqueteria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Paqueteria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Paqueteria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Paqueteria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Paqueteria().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.TextField Buscar;
    private javax.swing.JButton Calcular;
    private javax.swing.JTextField Codigo;
    private javax.swing.JTextPane Descripcion;
    private javax.swing.JTextField Destinatario;
    private javax.swing.JTextField Importe;
    private javax.swing.JButton Nuevo;
    private javax.swing.JTextField Paquetes;
    private javax.swing.JTextField Peso;
    private javax.swing.JButton Realizar;
    private javax.swing.JTextField Remitente;
    private javax.swing.JTabbedPane TEntregados;
    private javax.swing.JButton bBuscar;
    private javax.swing.JComboBox<String> chofer;
    private java.awt.Label codigo;
    private java.awt.Label descripcion;
    private java.awt.Label destinatario;
    private javax.swing.JComboBox<String> destino;
    private javax.swing.JComboBox<String> fecha;
    private java.awt.Label importe;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JComboBox<String> origen;
    private javax.swing.JPanel panelfondo;
    private java.awt.Label paquetes;
    private java.awt.Label peso;
    private java.awt.Label remitente;
    private javax.swing.JTable tentrega;
    private javax.swing.JTable trecibidos;
    private javax.swing.JComboBox<String> unidad;
    private javax.swing.JButton Entregar;
    // End of variables declaration//GEN-END:variables
}